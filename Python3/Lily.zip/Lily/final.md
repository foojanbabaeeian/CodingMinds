# Battleship 
# - coding function to spawn ships anywhere but no overlappping ships
# - shoot projecti;e to spot
# - shoot porjectile to X coordinate, Y coordinate. EX.  (5,8)
# - if projectile hit enemy ship say "HIT"
# - if not say "EMPTY" or "NOT HIT"
# - if sunk all enemy ships say "WIN"
# - if enemy sinks all your ships say "LOSE"
# - Computer vs Human or HUman vs human
# - function to make grid to put ships open



three ships 

long, short and medium 



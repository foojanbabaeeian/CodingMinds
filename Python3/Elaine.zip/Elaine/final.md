# "Magic Recipe Book"

# Pygame shows 3-5 ingredient buttons with pictures
# Click ingredients to select them
# Press "Create Recipe" button
# AI generates a silly recipe name + short description
# Display the result in a fun text box with animations
# That's it! Super simple loop
# import pygame
